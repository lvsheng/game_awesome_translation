define([], function () {
    return {
        hitBeing: 0, //被打者：大叔和情侣
        holeMask: 10, //洞的前挡板部分，挡住下面的大叔和情侣
        effectProp: 20, //道具：心、雾、+1、台词等
        hammer: 30 //但hammer在洞外生成，属于游戏层。
    };
});
